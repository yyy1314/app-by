package com.hua.huade001android;

import android.os.Bundle;


public class ConstraintLayoutDemoActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constraint_layout_demo);
    }

}
